
#include <iostream>
using namespace std;

int missing_number_in_an_sorted_array(int arr[], int n)  //if starting from 1
{
    int sum = 0;
    int s;
    int i;
    int missing_element;
    for (i=0; i<n ; i++)
    {
        sum = sum + arr[i];
    }
    
    s = (arr[n-1]*(arr[n-1]+1))/2;
    missing_element = s - sum;
    return missing_element;
    
}

void missing_number_in_an_sorted_array_not_starting_from1 (int arr[], int n)
{
    int l = arr[0];
    //int h = arr[n-1];
    int diff = l-0;
    for(int i=0; i<n; i++)
    {
        if(arr[i] - i != diff)
        {
            cout<<"Missing element is "<< i+diff << endl; 
            break;
        }
    }
}

void missing_element_in_a_sequence_sorted_array (int arr[], int n)
{
    int l = arr[0];
    int h = arr[n-1];
    int diff = l-0;
    for(int i=0; i<n; i++)
    {
        if(arr[i]-i != diff)
        {
            while (diff<arr[i]-i)
            {
                cout<<"missing element is "<<i+diff<<endl;
                diff++;
            }
        }
    }
}

void missing_element_in_an_unsorted_array(int arr[], int n)
{
    int max = 0;
    for(int i=0; i<n; i++)
    {
        if(arr[i] > max)
        {
            max = arr[i];
        }
    }
    
    int a[max];
    
    for(int i=0; i<n; i++)
    {
        a[arr[i]]++;
    }
    
    for (int i=1;i<=max; i++)
    {
        if(a[i] == 0)
        {
            cout<<"missing element is "<<i<<endl;
        }
    }
    
}

int main()
{
    int arr[11] = {1,2,3,4,5,6,8,9,10,11,12};
    //cout<<"missing element is "<<missing_number_in_an_sorted_array(arr,11)<<endl;
    
    int arr1[11] = {6,7,8,9,10,11,13,14,15,16,17};
    //missing_number_in_an_sorted_array_not_starting_from1(arr1,11);
    
    int arr2[11] = {6,7,8,9,11,12,15,16,17,18,19};
    //missing_element_in_a_sequence_sorted_array(arr2,11);
    
    int arr3[10] = {3,7,4,9,12,6,1,11,2,10};
    int arraysize = sizeof(arr3)/sizeof(arr3[0]);
    missing_element_in_an_unsorted_array(arr3, arraysize);
}

